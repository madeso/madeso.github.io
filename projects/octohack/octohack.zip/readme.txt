How to start:
Windows - run octohack.exe
OS X/Linux - run octohack.love with love2d 0.8 installed: https://love2d.org/

Controls:
arrows - move
r - rotate
space - split octopus
tab - switch between octopuses

Source:
http://code.google.com/p/octo-hack/

Credits:
Christian Costanza, Gustav Jansson, Jacob Michelsen and Giselle Otero, featuring music by David Nilsson