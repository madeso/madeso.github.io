Xplorer is a 2-player game created for the ludum dare 16 December 2009 competition designed and developed by Gustav �sirGustav� Jansson.

You play with a friend to explore a jungle world and the one who has the most treasures and the end wins. Use your mouse to walk or swim to new places and space to skip your current turn.


