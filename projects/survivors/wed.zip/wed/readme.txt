This is a simple proof of consept and most menues aren't working, but most features are designed with (game) world building in mind. Please keep this in mind when running the editor.

Run WorldEditor.exe

When the world editor has launched there is a menu bar at the top, the main view in the middle and the info bar at the bottom. Most menu items works but  the ones in File and help doesn't.

Currently there are only two working tools, the Camera tool and the Pen tool. Use the menu to select wich you want. The info bar att the bottom tells what tool you have selected.

Camera tool:
* press and hold lmb to rotate camera around focus
* press and hold rmb to move camera and focus
* scroll scroll-wheel to zoom

Pen tool:
* drag to make a line
* click(LMB) anywhere to place a start point, click again to place an endpoint and continue to drag several countinous lines  by clicking where you want the endpoints. click LMB or press Esc when you are done.

Tip: at any time press and hold shift to temporarily acces the camera tool.

Placing points:
By default your points ends up in your focal plane. The focal plane is always at your focal point, and faces you. When moving the cursor over a line and it becomes fat it means that you can place your points on the line and thus splitting it in two. If you move the cursor over the end points, or the middle point, of a line they become fat, indicating your point will be at that exact point.

If your line turns red, blue or green this means that it is along that axis.

To do:
* Add the eraser tool
* "reference" locking
* When pressing the scroll wheel, and moving the mouse, the camera should rotate around focus point
* automatic and non-automatic adding of faces like sketchup
* textures!
* auto uv map generation
* save & load levels
* subdivision and mesh simplification tools