Let's go cave-burrowing
a game made under 48 hours
by Gustav 'sirGustav' Jansson
for the Ludum Dare competition

You are a little monster that can fly and puke explosive bouncy goo, and you cannot die. Somewhere in the level there is a cake that you can�t eat.

Controls:
<Left mouse button> � flap your wings in the mouse-direction
<Right mouse button> � puke explosion balls in the mouse-direction
<Space> - changes these two if you like it that way
<R> - restarts the level
<Esc> - brings out this in-game help and then quits if pressed again, hit any mouse button to go back to the game

Have fun puking!